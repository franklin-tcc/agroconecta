document.addEventListener('DOMContentLoaded', () => {
  const APPS_SCRIPT_URL = 'https://script.google.com/a/macros/continental.edu.pe/s/AKfycbwxRIp2CKR-ZbPLpVBrmDJZYWKyJKjSlq6LGzIktq5LD6Ufg-kypXtAWOZtpoJFJi20Rg/exec';

  const baseProductos = [
    { id: 1, nombre: 'Maíz Gigante del Cusco', categoria: 'Granos', region: 'Sierra', tipo: 'Menor', precio: 3.80, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (1).jpeg', desc: 'Grano nativo del Valle Sagrado de Urubamba, ideal para chicha, mote y comida tradicional.', destacado: true },
    { id: 2, nombre: 'Maíz Morado Culli', categoria: 'Granos', region: 'Sierra', tipo: 'Menor', precio: 4.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM.jpeg', desc: 'Variedad andina con alto contenido de antocianinas y sabor distintivo.', destacado: true },
    { id: 3, nombre: 'Saco de maíz blanco (50kg)', categoria: 'Granos', region: 'Sierra', tipo: 'Mayor', precio: 175.00, unidad: '/ saco 50kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (2).jpeg', desc: 'Lote mayorista para restaurantes, molinos y distribuidores regionales.', destacado: false },
    { id: 4, nombre: 'Kiwicha orgánica', categoria: 'Granos', region: 'Sierra', tipo: 'Menor', precio: 9.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (5).jpeg', desc: 'Superalimento andino libre de amargor, rico en proteína y minerales.', destacado: false },
    { id: 5, nombre: 'Papa nativa Tumbay', categoria: 'Tubérculos', region: 'Sierra', tipo: 'Menor', precio: 2.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (7).jpeg', desc: 'Cosechada en zonas altas, con textura arenosa y sabor auténtico.', destacado: true },
    { id: 6, nombre: 'Papa Huamantanga', categoria: 'Tubérculos', region: 'Sierra', tipo: 'Menor', precio: 3.20, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (8).jpeg', desc: 'Papa cremosa y sabrosa ideal para sopas, guisos y platos caseros.', destacado: false },
    { id: 7, nombre: 'Saco de papa camotillo (100kg)', categoria: 'Tubérculos', region: 'Sierra', tipo: 'Mayor', precio: 210.00, unidad: '/ saco 100kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (9).jpeg', desc: 'Producto para venta institucional y distribución regional de alto volumen.', destacado: false },
    { id: 8, nombre: 'Camote morado de valle', categoria: 'Tubérculos', region: 'Sierra', tipo: 'Menor', precio: 2.80, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (11).jpeg', desc: 'Dulce, nutritivo y muy demandado por su sabor natural y color intenso.', destacado: false },
    { id: 9, nombre: 'Palta Hass premium', categoria: 'Frutas', region: 'Costa', tipo: 'Menor', precio: 5.00, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (2).jpeg', desc: 'Fruto de textura cremosa y sabor equilibrado, ideal para consumo directo.', destacado: true },
    { id: 10, nombre: 'Jaba de palta Hass (20kg)', categoria: 'Frutas', region: 'Costa', tipo: 'Mayor', precio: 90.00, unidad: '/ jaba 20kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (3).jpeg', desc: 'Caja seleccionada para comercio mayorista y distribución comercial.', destacado: false },
    { id: 11, nombre: 'Mango Kent de Chulucanas', categoria: 'Frutas', region: 'Costa', tipo: 'Menor', precio: 4.80, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (5).jpeg', desc: 'Mango dulce y jugoso, muy solicitado en mercados locales y regionales.', destacado: false },
    { id: 12, nombre: 'Lúcuma de seda', categoria: 'Frutas', region: 'Sierra', tipo: 'Menor', precio: 7.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (2).jpeg', desc: 'Aroma intenso y pulpa cremosa para heladería, postres y jugos.', destacado: false },
    { id: 13, nombre: 'Quinua orgánica roja', categoria: 'Superalimentos', region: 'Sierra', tipo: 'Menor', precio: 12.00, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (5).jpeg', desc: 'Grano andino de alto valor nutricional, perfecto para preparación saludable.', destacado: true },
    { id: 14, nombre: 'Quinua blanca pearl', categoria: 'Superalimentos', region: 'Sierra', tipo: 'Menor', precio: 10.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (5).jpeg', desc: 'Variedad amable, limpia y de excelente cocción para cocina diaria.', destacado: false },
    { id: 15, nombre: 'Saco de quinua blanca (25kg)', categoria: 'Superalimentos', region: 'Sierra', tipo: 'Mayor', precio: 230.00, unidad: '/ saco 25kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (5).jpeg', desc: 'Presentación ideal para distribuidores y negocios de alimentación saludable.', destacado: false },
    { id: 16, nombre: 'Yuca amarilla de selva', categoria: 'Tubérculos', region: 'Selva', tipo: 'Menor', precio: 2.60, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (1).jpeg', desc: 'Raíz de excelente rendimiento y sabor suave para cocina tradicional.', destacado: false },
    { id: 17, nombre: 'Papa canchán comercial', categoria: 'Tubérculos', region: 'Costa', tipo: 'Menor', precio: 1.80, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (10).jpeg', desc: 'Opción accesible para restaurantes y venta local con buena competitividad.', destacado: false },
    { id: 18, nombre: 'Palta fuerte de valle', categoria: 'Frutas', region: 'Costa', tipo: 'Menor', precio: 6.00, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (4).jpeg', desc: 'Palta de excelente consistencia para consumo y preparación de alimentos.', destacado: false },
    { id: 19, nombre: 'Chirimoya Cumbe', categoria: 'Frutas', region: 'Sierra', tipo: 'Menor', precio: 8.50, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.20.00 PM (4).jpeg', desc: 'Pulpa blanca, dulce y jugosa con gran valor para el mercado gourmet.', destacado: false },
    { id: 20, nombre: 'Tarwi / chocho lavado', categoria: 'Granos', region: 'Sierra', tipo: 'Menor', precio: 8.00, unidad: '/ kg', img: 'Imagenes/WhatsApp Image 2026-11-06 at 3.19.59 PM (6).jpeg', desc: 'Leguminosa andina rica en proteína para dietas balanceadas y tradicionales.', destacado: false }
  ];

  let filtroBusqueda = '';
  let productosFiltrados = [...baseProductos];
  let cart = [];

  const catalogoGrid = document.getElementById('catalogoGrid');
  const destacadosContainer = document.getElementById('destacadosContainer');
  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');
  const searchBtn = document.getElementById('searchBtn');
  const sortSelect = document.getElementById('sortSelect');
  const resultsCount = document.getElementById('resultsCount');
  const cartCount = document.getElementById('cartCount');
  const cartModal = document.getElementById('cartModal');
  const cartItemsContainer = document.getElementById('cartItemsContainer');
  const cartTotal = document.getElementById('cartTotal');
  const toast = document.getElementById('toast');

  function cambiarPestana(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => {
      tab.classList.toggle('active', tab.id === tabId);
    });

    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });

    const navMenu = document.getElementById('nav-menu');
    if (navMenu && navMenu.classList.contains('show')) {
      navMenu.classList.remove('show');
    }
  }

  document.querySelectorAll('.tab-btn, .nav-tab').forEach(button => {
    button.addEventListener('click', () => {
      const tab = button.dataset.tab;
      if (!tab) return;
      const role = button.dataset.role;
      if (role === 'Comprador' || role === 'Distribuidor' || role === 'Productor') seleccionarRol(role);
      cerrarModal(cartModal);
      cerrarModal(profileModal);
      cambiarPestana(tab);
    });
  });

  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');
  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('show');
      menuToggle.setAttribute('aria-expanded', navMenu.classList.contains('show'));
    });
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3200);
  }

  const supportChatPanel = document.getElementById('supportChatPanel');
  const supportChatToggle = document.getElementById('supportChatToggle');
  const supportChatMessages = document.getElementById('supportChatMessages');
  const supportChatForm = document.getElementById('supportChatForm');

  function responderConsulta(message) {
    const query = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const answers = [
      {
        pattern: /devol|reembols|reclamo|producto.*danad|producto.*mal/,
        text: 'Para solicitar una revisión, conserva el comprobante y toma fotografías del producto y su empaque. Contacta a AgroConecta lo antes posible e indica el producto, la fecha y el motivo. La política publicada describe el proceso orientativo; no se tramitan reembolsos automáticamente desde esta web.',
        link: 'atencion.html?tema=devoluciones'
      },
      {
        pattern: /envio|entrega|delivery|transport|ruta|costo.*flete/,
        text: 'El envío depende del origen, destino, volumen y tipo de carga. Antes de confirmar una compra, acuerda por escrito la fecha, el costo y quién recibe el pedido. Esta web es un prototipo y no calcula ni asigna transportistas automáticamente.',
        link: 'atencion.html?tema=envios'
      },
      {
        pattern: /proteccion.*compra|compra.*segur|garantia|estafa/,
        text: 'Revisa la identidad y los datos de contacto de la contraparte, confirma producto, cantidad, precio y entrega por escrito, y conserva comprobantes. La plataforma no custodia pagos ni ofrece cobertura financiera automática en esta versión.',
        link: 'atencion.html?tema=proteccion'
      },
      {
        pattern: /contrasen|iniciar sesion|ingresar|mi cuenta|cuenta|registro.*comprador/,
        text: 'Regístrate con un correo válido y una contraseña de al menos 8 caracteres. Luego abre “Mi cuenta” e ingresa con el mismo correo y contraseña. En esta versión los datos quedan en el navegador de este dispositivo; no existe recuperación de contraseña en servidor.',
        link: null
      },
      {
        pattern: /agricultor|productor|cosecha|cultivo|public/,
        text: 'El registro agrícola conserva sus tres fases: datos personales, ubicación y actividad/cultivos. Entra en Contacto, selecciona “Agricultor” y completa el formulario. La ubicación y los documentos son datos sensibles; este prototipo no verifica ni transmite archivos.',
        link: null
      },
      {
        pattern: /transportista|licencia|soat|vehiculo|conductor/,
        text: 'El registro de transportista solicita información de contacto, vehículo, capacidad, placa, licencia y rutas. Los archivos seleccionados no se envían a un servidor en esta versión; no adjuntes documentos reales hasta que exista un canal seguro.',
        link: null
      },
      {
        pattern: /carrito|producto|precio|comprar|pedido|cantidad/,
        text: 'Puedes agregar productos al carrito y ajustar cantidades. El total mostrado es referencial: no confirma un pedido, no reserva inventario y no procesa pagos. Acuerda la disponibilidad y condiciones con el proveedor antes de comprar.',
        link: null
      },
      {
        pattern: /actividad sospechosa|report|fraude|suplant|phishing|enlace sospech/,
        text: 'No compartas contraseñas ni códigos, evita enlaces desconocidos y guarda capturas y comprobantes. Reporta el caso desde la página de atención al cliente e incluye fecha, perfil involucrado y evidencia sin publicar datos personales.',
        link: 'atencion.html?tema=actividad'
      },
      {
        pattern: /propiedad intelectual|derecho de autor|marca|imagen.*copi/,
        text: 'Si encuentras contenido que consideras usado sin autorización, identifica la página, describe la obra y adjunta evidencia de titularidad en tu comunicación a atención al cliente.',
        link: 'atencion.html?tema=propiedad'
      },
      {
        pattern: /terminos|condiciones|privacidad|dato personal/,
        text: 'Consulta los términos y condiciones y las políticas de atención para conocer el alcance del prototipo y las pautas de uso. La documentación informativa no reemplaza asesoría legal.',
        link: 'atencion.html?tema=terminos'
      },
      {
        pattern: /hola|buenos dias|buenas tardes|buenas noches|ayuda/,
        text: 'Con gusto te oriento. Escribe una consulta sobre compras, productos, registros, entregas, devoluciones o seguridad. Para una situación particular que no pueda resolver, puedo dirigirte a atención al cliente.',
        link: null
      }
    ];
    const match = answers.find(answer => answer.pattern.test(query));
    if (match) return match;
    return {
      text: 'No tengo información suficiente para responder esa consulta con seguridad. Contacta a atención al cliente en contacto@agroconecta.pe o por WhatsApp al +51 984000000. No envíes contraseñas, códigos ni documentos personales por el chat.',
      link: 'atencion.html?tema=actividad'
    };
  }

  function agregarMensajeChat(message, sender, link) {
    if (!supportChatMessages) return;
    const bubble = document.createElement('p');
    bubble.className = `chat-message ${sender}`;
    bubble.textContent = message;
    supportChatMessages.appendChild(bubble);
    if (link) {
      const linkElement = document.createElement('a');
      linkElement.className = 'chat-policy-link';
      linkElement.href = link;
      linkElement.textContent = 'Ver información relacionada';
      supportChatMessages.appendChild(linkElement);
    }
    supportChatMessages.scrollTop = supportChatMessages.scrollHeight;
  }

  function setChatOpen(open) {
    if (!supportChatPanel || !supportChatToggle) return;
    supportChatPanel.hidden = !open;
    supportChatToggle.setAttribute('aria-expanded', String(open));
    if (open) document.getElementById('supportChatInput')?.focus();
  }

  supportChatToggle?.addEventListener('click', () => setChatOpen(supportChatPanel.hidden));
  document.getElementById('supportChatClose')?.addEventListener('click', () => setChatOpen(false));
  supportChatForm?.addEventListener('submit', event => {
    event.preventDefault();
    const input = document.getElementById('supportChatInput');
    const message = input.value.trim();
    if (!message) return;
    agregarMensajeChat(message, 'user');
    input.value = '';
    window.setTimeout(() => {
      const response = responderConsulta(message);
      agregarMensajeChat(response.text, 'assistant', response.link);
    }, 220);
  });

  document.getElementById('newsletterForm')?.addEventListener('submit', event => {
    event.preventDefault();
    showToast('La suscripción por correo aún no está habilitada en esta versión.');
  });

  function generarCardHTML(producto) {
    return `
      <article class="product-card">
        <div class="product-image-wrap">
          <img src="${producto.img}" alt="${producto.nombre}" />
          <span class="product-badge">${producto.categoria}</span>
        </div>
        <div class="product-content">
          <div class="product-row">
            <span class="product-region">${producto.region}</span>
            <div class="product-price">S/ ${producto.precio.toFixed(2)} <small>${producto.unidad}</small></div>
          </div>
          <h3 class="product-name">${producto.nombre}</h3>
          <p class="product-desc">${producto.desc}</p>
          <div class="product-footer">
            <button type="button" class="btn-add" data-id="${producto.id}" data-producto="${producto.nombre}" data-precio="${producto.precio}" data-img="${producto.img}">Agregar</button>
            <button type="button" class="btn-quote" data-producto="${producto.nombre}">Registro</button>
          </div>
        </div>
      </article>
    `;
  }

  function renderizarDestacados() {
    if (!destacadosContainer) return;
    const destacados = baseProductos.filter(producto => producto.destacado).slice(0, 4);
    destacadosContainer.innerHTML = destacados.map(generarCardHTML).join('');
    asignarEventosProductos();
  }

  function aplicarFiltrosYLógica() {
    const categoriasSeleccionadas = Array.from(document.querySelectorAll('.cat-filter:checked')).map(cb => cb.value.trim().toLowerCase());
    const regionesSeleccionadas = Array.from(document.querySelectorAll('.region-filter:checked')).map(cb => cb.value.trim());
    const tiposSeleccionados = Array.from(document.querySelectorAll('.tipo-filter:checked')).map(cb => cb.value.trim());

    const minPrice = parseFloat(document.getElementById('minPrice')?.value) || 0;
    const maxPrice = parseFloat(document.getElementById('maxPrice')?.value) || 999999;

    productosFiltrados = baseProductos.filter(producto => {
      const coincideTexto = !filtroBusqueda || [producto.nombre, producto.categoria, producto.desc].some(valor => valor.toLowerCase().includes(filtroBusqueda));
      const coincideCategoria = categoriasSeleccionadas.length === 0 || categoriasSeleccionadas.some(cat => producto.categoria.toLowerCase().includes(cat));
      const coincideRegion = regionesSeleccionadas.length === 0 || regionesSeleccionadas.includes(producto.region);
      const coincideTipo = tiposSeleccionados.length === 0 || tiposSeleccionados.includes(producto.tipo);
      const coincidePrecio = producto.precio >= minPrice && producto.precio <= maxPrice;

      return coincideTexto && coincideCategoria && coincideRegion && coincideTipo && coincidePrecio;
    });

    const orden = sortSelect ? sortSelect.value : 'recientes';
    if (orden === 'precio-asc') {
      productosFiltrados.sort((a, b) => a.precio - b.precio);
    } else if (orden === 'precio-desc') {
      productosFiltrados.sort((a, b) => b.precio - a.precio);
    } else {
      productosFiltrados.sort((a, b) => a.id - b.id);
    }

    if (catalogoGrid) {
      catalogoGrid.innerHTML = productosFiltrados.map(generarCardHTML).join('');
    }

    if (resultsCount) {
      resultsCount.textContent = `Mostrando ${productosFiltrados.length} productos seleccionados`;
    }

    asignarEventosProductos();
  }

  document.querySelectorAll('.cat-filter, .region-filter, .tipo-filter').forEach(checkbox => {
    checkbox.addEventListener('change', aplicarFiltrosYLógica);
  });

  const minPriceInput = document.getElementById('minPrice');
  const maxPriceInput = document.getElementById('maxPrice');
  if (minPriceInput) minPriceInput.addEventListener('input', aplicarFiltrosYLógica);
  if (maxPriceInput) maxPriceInput.addEventListener('input', aplicarFiltrosYLógica);

  document.getElementById('applyFiltersBtn')?.addEventListener('click', aplicarFiltrosYLógica);
  sortSelect?.addEventListener('change', aplicarFiltrosYLógica);

  document.getElementById('resetFiltersBtn')?.addEventListener('click', () => {
    document.querySelectorAll('.cat-filter, .region-filter, .tipo-filter').forEach(cb => cb.checked = true);
    if (minPriceInput) minPriceInput.value = '1.00';
    if (maxPriceInput) maxPriceInput.value = '900.00';
    if (searchInput) searchInput.value = '';
    filtroBusqueda = '';
    aplicarFiltrosYLógica();
    showToast('Filtros reestablecidos.');
  });

  document.querySelectorAll('.cat-circle').forEach(circle => {
    circle.addEventListener('click', () => {
      const categoria = circle.getAttribute('data-categoria').trim();
      filtroBusqueda = '';
      if (searchInput) searchInput.value = '';

      document.querySelectorAll('.cat-filter').forEach(checkbox => {
        checkbox.checked = checkbox.value.toLowerCase().includes(categoria.toLowerCase());
      });

      aplicarFiltrosYLógica();
      cambiarPestana('tab-catalogo');
      showToast(`Filtrando categoría: "${categoria}"`);
    });
  });

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', (event) => {
      const query = event.target.value.trim().toLowerCase();

      if (!query) {
        searchResults.innerHTML = '';
        searchResults.classList.remove('show');
        return;
      }

      const coincidencias = baseProductos.filter(producto =>
        producto.nombre.toLowerCase().includes(query) ||
        producto.categoria.toLowerCase().includes(query) ||
        producto.desc.toLowerCase().includes(query)
      );

      if (coincidencias.length === 0) {
        searchResults.innerHTML = `<div class="no-results-msg">No se encontraron productos con "${query}"</div>`;
      } else {
        searchResults.innerHTML = coincidencias.slice(0, 8).map(producto => `
          <div class="search-item-option" onclick="seleccionarSugerencia('${producto.nombre}')">
            <img src="${producto.img}" alt="${producto.nombre}" />
            <div class="search-item-info">
              <span class="search-item-title">${producto.nombre}</span>
              <span class="search-item-meta">${producto.categoria} • ${producto.region}</span>
            </div>
            <span class="search-item-price">S/ ${producto.precio.toFixed(2)}</span>
          </div>
        `).join('');
      }

      searchResults.classList.add('show');
    });

    document.addEventListener('click', (event) => {
      if (!event.target.closest('.search-box-container')) {
        searchResults.classList.remove('show');
      }
    });
  }

  searchBtn?.addEventListener('click', () => {
    filtroBusqueda = searchInput.value.trim().toLowerCase();
    aplicarFiltrosYLógica();
    cambiarPestana('tab-catalogo');
  });

  window.seleccionarSugerencia = function(nombreProducto) {
    if (searchResults) searchResults.classList.remove('show');
    if (searchInput) searchInput.value = nombreProducto;
    filtroBusqueda = nombreProducto.trim().toLowerCase();
    aplicarFiltrosYLógica();
    cambiarPestana('tab-catalogo');
    showToast(`Resultados para: "${nombreProducto}"`);
  };

  const profileModal = document.getElementById('profileModal');
  const profileList = document.getElementById('profileList');
  const roleInput = document.getElementById('rol');
  const registrationTitle = document.getElementById('registrationTitle');
  const transportFields = document.getElementById('transportFields');
  const buyerFields = document.getElementById('buyerFields');
  const farmerRegistrationPanel = document.getElementById('farmerRegistrationPanel');
  const registrationTrust = document.getElementById('registrationTrust');
  const registrationForm = document.getElementById('registroForm');
  const farmerRegistrationFrame = document.getElementById('farmerRegistrationFrame');
  const roleLabels = {
    Comprador: 'comprador',
    Productor: 'agricultor',
    Distribuidor: 'transportista'
  };
  let selectedRole = 'Comprador';

  function abrirModal(modal) {
    if (!modal) return;
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
  }

  function cerrarModal(modal) {
    if (!modal) return;
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
  }

  function seleccionarRol(role) {
    if (!Object.prototype.hasOwnProperty.call(roleLabels, role)) return;
    selectedRole = role;
    if (roleInput) roleInput.value = role;
    if (registrationTitle) registrationTitle.textContent = role === 'Productor'
      ? 'Registro de agricultor'
      : `Registro de ${roleLabels[role]}`;
    if (transportFields) transportFields.hidden = role !== 'Distribuidor';
    if (buyerFields) buyerFields.hidden = role !== 'Comprador';
    if (registrationForm) registrationForm.hidden = role === 'Productor';
    if (farmerRegistrationPanel) farmerRegistrationPanel.hidden = role !== 'Productor';
    if (registrationTrust) registrationTrust.hidden = role === 'Productor';

    document.querySelectorAll('[data-role-select]').forEach(button => {
      const selected = button.dataset.roleSelect === role;
      button.classList.toggle('active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });

    ['direccionEntrega'].forEach(id => {
      const input = document.getElementById(id);
      if (input) input.required = role === 'Comprador';
    });

    ['vehiculo', 'capacidad', 'placaVehiculo', 'licenciaNumero', 'licenciaCategoria',
      'licenciaVencimiento', 'zonasServicio', 'soatVigente', 'revisionTecnica',
      'licenciaFrontal', 'licenciaPosterior'].forEach(id => {
      const input = document.getElementById(id);
      if (input) input.required = role === 'Distribuidor';
    });
  }

  window.addEventListener('message', event => {
    if (!farmerRegistrationFrame || event.source !== farmerRegistrationFrame.contentWindow) return;
    if (event.origin !== window.location.origin && event.origin !== 'null') return;
    if (event.data?.type !== 'agroconecta:resize') return;
    const height = Number(event.data.height);
    if (Number.isFinite(height) && height >= 500 && height <= 3200) {
      farmerRegistrationFrame.style.height = `${height}px`;
    }
  });

  function actualizarContadorCarrito() {
    if (cartCount) {
      cartCount.textContent = cart.reduce((total, item) => total + item.cantidad, 0);
    }
  }

  function asignarEventosProductos() {
    document.querySelectorAll('.btn-add').forEach(button => {
      button.onclick = () => {
        const productName = button.dataset.producto || 'Producto';
        const productId = Number(button.dataset.id);
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
          existingItem.cantidad += 1;
        } else {
          cart.push({
            id: productId,
            nombre: productName,
            precio: parseFloat(button.dataset.precio) || 0,
            img: button.dataset.img || '',
            cantidad: 1
          });
        }
        actualizarContadorCarrito();
        showToast(`"${productName}" agregado al carrito.`);
      };
    });

    document.querySelectorAll('.btn-quote').forEach(button => {
      button.onclick = () => {
        seleccionarRol('Comprador');
        cambiarPestana('tab-contacto');
        document.getElementById('nombre')?.focus();
      };
    });
  }

  function renderCart() {
    if (!cartItemsContainer || !cartTotal) return;
    if (cart.length === 0) {
      cartItemsContainer.innerHTML = '<p class="empty-cart-msg">Tu carrito está vacío por el momento.</p>';
      cartTotal.textContent = 'S/ 0.00';
      return;
    }

    let total = 0;
    cartItemsContainer.innerHTML = cart.map((item, index) => {
      const subtotal = item.precio * item.cantidad;
      total += subtotal;
      return `
        <div class="cart-item-row">
          <img src="${item.img}" alt="${item.nombre}" />
          <div class="cart-item-info">
            <strong>${item.nombre}</strong><br />
            <small>S/ ${item.precio.toFixed(2)} c/u · Subtotal: S/ ${subtotal.toFixed(2)}</small>
          </div>
          <div class="quantity-controls" aria-label="Cantidad de ${item.nombre}">
            <button type="button" data-cart-action="decrease" data-index="${index}" aria-label="Reducir cantidad de ${item.nombre}">−</button>
            <span>${item.cantidad}</span>
            <button type="button" data-cart-action="increase" data-index="${index}" aria-label="Aumentar cantidad de ${item.nombre}">+</button>
          </div>
          <button class="remove-cart-item" type="button" data-cart-action="remove" data-index="${index}" aria-label="Eliminar ${item.nombre}">×</button>
        </div>
      `;
    }).join('');
    cartTotal.textContent = `S/ ${total.toFixed(2)}`;
  }

  if (cartItemsContainer) {
    cartItemsContainer.addEventListener('click', event => {
      const button = event.target.closest('[data-cart-action]');
      if (!button) return;
      const index = Number(button.dataset.index);
      const item = cart[index];
      if (!item) return;
      if (button.dataset.cartAction === 'increase') item.cantidad += 1;
      if (button.dataset.cartAction === 'decrease' && item.cantidad > 1) item.cantidad -= 1;
      if (button.dataset.cartAction === 'remove') cart.splice(index, 1);
      actualizarContadorCarrito();
      renderCart();
    });
  }

  document.getElementById('openCartBtn')?.addEventListener('click', () => {
    abrirModal(cartModal);
    renderCart();
  });
  document.getElementById('closeCart')?.addEventListener('click', () => cerrarModal(cartModal));
  document.getElementById('closeProfile')?.addEventListener('click', () => cerrarModal(profileModal));
  window.closeCartModal = () => cerrarModal(cartModal);

  window.removeItem = function(index) {
    if (!Number.isInteger(index) || index < 0 || index >= cart.length) return;
    cart.splice(index, 1);
    actualizarContadorCarrito();
    renderCart();
  };

  [cartModal, profileModal].forEach(modal => {
    modal?.addEventListener('click', event => {
      if (event.target === modal) cerrarModal(modal);
    });
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      cerrarModal(cartModal);
      cerrarModal(profileModal);
    }
  });

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    })[character]);
  }

  function renderizarPerfiles() {
    if (!profileList) return;
    let profiles;
    try {
      profiles = window.AgroCuentas.obtenerPerfilesSesion();
    } catch (error) {
      console.error('No se pudo leer la sesión de la cuenta:', error);
      profileList.innerHTML = '<p class="profile-empty">No se pudo leer la sesión. Cierra y vuelve a abrir esta ventana.</p>';
      return;
    }

    if (profiles.length === 0) {
      profileList.innerHTML = '<p class="profile-empty">Inicia sesión con el correo y la contraseña usados durante el registro. Si aún no tienes cuenta, puedes crear un registro.</p>';
      document.getElementById('accountLoginForm').hidden = false;
      document.querySelector('.account-note').hidden = false;
      document.querySelector('.account-disclaimer').hidden = false;
      document.getElementById('accountLogout').hidden = true;
      document.getElementById('accountStatus').textContent = '';
      return;
    }

    document.getElementById('accountLoginForm').hidden = true;
    document.querySelector('.account-note').hidden = true;
    document.querySelector('.account-disclaimer').hidden = true;
    document.getElementById('accountLogout').hidden = false;
    document.getElementById('accountStatus').textContent = 'Sesión iniciada en este dispositivo.';
    profileList.innerHTML = profiles.map(profile => {
      const details = [
        ['Correo', profile.email],
        ['Teléfono', profile.telefono],
        ['DNI / RUC', profile.dniRuc],
        ['Ciudad o zona', profile.ubicacion],
        ...Object.entries(profile.detalles || {}).map(([label, value]) => [label, value])
      ].filter(([, value]) => value);

      return `
        <article class="profile-record">
          <div class="profile-record-heading">
            <div><span class="profile-role">${escapeHTML(roleLabels[profile.rol] || 'usuario')}</span><h4>${escapeHTML(profile.nombre)}</h4></div>
            <small>${escapeHTML(profile.creadoEn)}</small>
          </div>
          <dl>${details.map(([label, value]) => `
            <div><dt>${escapeHTML(label)}</dt><dd>${escapeHTML(value)}</dd></div>
          `).join('')}</dl>
        </article>
      `;
    }).join('');
  }

  document.getElementById('openProfileBtn')?.addEventListener('click', () => {
    renderizarPerfiles();
    abrirModal(profileModal);
  });
  document.getElementById('accountLoginForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const status = document.getElementById('accountStatus');
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    status.textContent = 'Verificando datos de acceso...';
    try {
      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value;
      const authenticated = await window.AgroCuentas.iniciarSesion(email, password);
      if (authenticated.length === 0) {
        status.textContent = 'Correo o contraseña incorrectos. Si tu registro es anterior a esta función, vuelve a registrarte para crear una credencial.';
        return;
      }
      form.reset();
      renderizarPerfiles();
    } catch (error) {
      console.error('No se pudo iniciar sesión:', error);
      status.textContent = error.message || 'No se pudo iniciar sesión. Inténtalo nuevamente.';
    } finally {
      submitButton.disabled = false;
    }
  });
  document.getElementById('accountLogout')?.addEventListener('click', () => {
    window.AgroCuentas.cerrarSesion();
    renderizarPerfiles();
  });
  document.querySelectorAll('[data-password-toggle]').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.dataset.passwordToggle);
      if (!input) return;
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      button.textContent = show ? 'Ocultar' : 'Mostrar';
      button.setAttribute('aria-label', `${show ? 'Ocultar' : 'Mostrar'} contraseña`);
    });
  });
  document.querySelectorAll('[data-role-select]').forEach(button => {
    button.addEventListener('click', () => seleccionarRol(button.dataset.roleSelect));
  });

  const registroForm = document.getElementById('registroForm');
  if (registroForm) {
    registroForm.addEventListener('reset', () => {
      window.setTimeout(() => seleccionarRol(selectedRole), 0);
    });

    registroForm.addEventListener('submit', async event => {
      event.preventDefault();
      const password = document.getElementById('passwordRegistro').value;
      const confirmPassword = document.getElementById('confirmarPasswordRegistro').value;
      if (password !== confirmPassword) {
        const confirmInput = document.getElementById('confirmarPasswordRegistro');
        const passwordInput = document.getElementById('passwordRegistro');
        const clearMismatch = () => confirmInput.setCustomValidity('');
        confirmInput.setCustomValidity('Las contraseñas no coinciden.');
        confirmInput.reportValidity();
        confirmInput.addEventListener('input', clearMismatch, { once: true });
        passwordInput.addEventListener('input', clearMismatch, { once: true });
        return;
      }

      if (selectedRole === 'Distribuidor') {
        const maxFileSize = 5 * 1024 * 1024;
        const invalidFileId = ['licenciaFrontal', 'licenciaPosterior'].find(id => {
          const file = document.getElementById(id).files[0];
          return !file || file.size > maxFileSize ||
            !(file.type.startsWith('image/') || file.type === 'application/pdf' || /\.pdf$/i.test(file.name));
        });
        if (invalidFileId) {
          const input = document.getElementById(invalidFileId);
          input.setCustomValidity('Adjunta una imagen o un PDF de hasta 5 MB.');
          input.reportValidity();
          input.addEventListener('change', () => input.setCustomValidity(''), { once: true });
          return;
        }

        const today = new Date();
        const todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const licenseExpiry = new Date(`${document.getElementById('licenciaVencimiento').value}T00:00:00`);
        if (licenseExpiry < todayDate) {
          const input = document.getElementById('licenciaVencimiento');
          input.setCustomValidity('La fecha de vencimiento debe ser hoy o posterior.');
          input.reportValidity();
          input.addEventListener('change', () => input.setCustomValidity(''), { once: true });
          return;
        }
      }

      const btnSubmit = document.getElementById('btnSubmit');
      const btnText = btnSubmit?.querySelector('.btn-text');
      const spinner = btnSubmit?.querySelector('.spinner');
      if (btnSubmit) btnSubmit.disabled = true;
      if (btnText) btnText.textContent = 'Guardando registro...';
      if (spinner) spinner.hidden = false;

      const profile = {
        rol: roleInput.value,
        nombre: document.getElementById('nombre').value.trim(),
        email: document.getElementById('email').value.trim(),
        telefono: document.getElementById('telefono').value.trim(),
        ubicacion: document.getElementById('ubicacion').value.trim(),
        dniRuc: document.getElementById('dni_ruc').value.trim(),
        creadoEn: new Date().toLocaleString('es-PE'),
        detalles: {}
      };
      const extraFields = profile.rol === 'Distribuidor'
        ? [
          ['Vehículo', 'vehiculo'], ['Capacidad de carga', 'capacidad'], ['Placa', 'placaVehiculo'],
          ['Licencia de conducir', 'licenciaNumero'], ['Categoría de licencia', 'licenciaCategoria'],
          ['Vencimiento de licencia', 'licenciaVencimiento'], ['Rutas', 'zonasServicio'],
          ['SOAT vigente', 'soatVigente'], ['Revisión técnica vigente', 'revisionTecnica'],
          ['Archivo frontal de licencia (no almacenado)', 'licenciaFrontal'],
          ['Archivo posterior de licencia (no almacenado)', 'licenciaPosterior']
        ]
        : [['Dirección de entrega', 'direccionEntrega']];
      extraFields.forEach(([label, id]) => {
        const input = document.getElementById(id);
        const value = input.type === 'file' ? input.files[0]?.name : input.value.trim();
        if (value) profile.detalles[label] = value;
      });

      let localSaveError = null;
      try {
        profile.credencial = await window.AgroCuentas.crearCredencial(password);
        window.AgroCuentas.guardarPerfil(profile);
        window.AgroCuentas.establecerSesion(profile.email, [profile.rol]);
      } catch (error) {
        localSaveError = error;
        console.error('No se pudo guardar el registro en este dispositivo:', error);
      }

      const formData = new URLSearchParams();
      formData.append('action', 'registrarUsuario');
      formData.append('nombre', profile.nombre);
      formData.append('email', profile.email);
      formData.append('rol', profile.rol);
      formData.append('telefono', profile.telefono);
      formData.append('ubicacion_gps', profile.ubicacion);
      formData.append('dni_ruc', profile.dniRuc);

      try {
        if (!localSaveError) {
          await fetch(APPS_SCRIPT_URL, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
            body: formData.toString()
          });
        }

        if (localSaveError) {
          showToast(localSaveError.message || 'No se pudo guardar el perfil en este dispositivo.');
        } else {
          showToast('Perfil y acceso guardados en este dispositivo. Se solicitó sincronizar los datos básicos.');
          registroForm.reset();
          seleccionarRol('Comprador');
        }
      } catch (error) {
        if (!localSaveError) console.error('No se pudo enviar la solicitud al registro central:', error);
        if (localSaveError) {
          showToast(localSaveError.message || 'No se pudo guardar el perfil en este dispositivo.');
        } else {
          showToast('Perfil guardado en este dispositivo; no se pudo conectar con el registro central.');
          registroForm.reset();
          seleccionarRol('Comprador');
        }
      } finally {
        if (btnSubmit) btnSubmit.disabled = false;
        if (btnText) btnText.textContent = 'Crear registro';
        if (spinner) spinner.hidden = true;
      }
    });
  }

  seleccionarRol('Comprador');

  renderizarDestacados();
  aplicarFiltrosYLógica();
});